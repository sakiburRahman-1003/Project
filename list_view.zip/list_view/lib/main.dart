import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fruit List',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const FruitListScreen(),
    );
  }
}

class Fruit {
  final String name;
  final IconData icon;
  final Color color;

  Fruit({required this.name, required this.icon, required this.color});
}

class FruitListScreen extends StatelessWidget {
  const FruitListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // List of fruits with their icons and colors
    final List<Fruit> fruits = [
      Fruit(
        name: 'Apple',
        icon: Icons.apple,
        color: Colors.red.shade100,
      ),
      Fruit(
        name: 'Banana',
        icon: Icons.water_drop_outlined,
        color: Colors.yellow.shade100,
      ),
      Fruit(
        name: 'Orange',
        icon: Icons.circle,
        color: Colors.orange.shade100,
      ),
      Fruit(
        name: 'Strawberry',
        icon: Icons.favorite,
        color: Colors.pink.shade100,
      ),
      Fruit(
        name: 'Blueberry',
        icon: Icons.lens,
        color: Colors.blue.shade100,
      ),
      Fruit(
        name: 'Watermelon',
        icon: Icons.panorama_fish_eye,
        color: Colors.green.shade100,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fruit List'),
        elevation: 2,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: fruits.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 2,
            margin: const EdgeInsets.symmetric(vertical: 6),
            color: fruits[index].color,
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: CircleAvatar(
                backgroundColor: fruits[index].color,
                radius: 25,
                child: Icon(
                  fruits[index].icon,
                  color: _getIconColor(fruits[index].name),
                  size: 30,
                ),
              ),
              title: Text(
                fruits[index].name,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text('Tap to see details'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FruitDetailScreen(fruit: fruits[index]),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Color _getIconColor(String fruitName) {
    switch (fruitName) {
      case 'Apple':
        return Colors.red;
      case 'Banana':
        return Colors.yellow.shade700;
      case 'Orange':
        return Colors.orange;
      case 'Strawberry':
        return Colors.red;
      case 'Blueberry':
        return Colors.indigo;
      case 'Watermelon':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}

class FruitDetailScreen extends StatelessWidget {
  final Fruit fruit;

  const FruitDetailScreen({Key? key, required this.fruit}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(fruit.name),
        backgroundColor: fruit.color,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Custom fruit logo
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                color: fruit.color,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Center(
                child: Icon(
                  fruit.icon,
                  size: 80,
                  color: _getIconColor(fruit.name),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              fruit.name,
              style: const TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'This is a delicious ${fruit.name.toLowerCase()}!',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 32),
            // A more custom styled back button
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: fruit.color,
                foregroundColor: _getIconColor(fruit.name),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              icon: const Icon(Icons.arrow_back),
              label: const Text(
                'Back to List',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getIconColor(String fruitName) {
    switch (fruitName) {
      case 'Apple':
        return Colors.red;
      case 'Banana':
        return Colors.yellow.shade700;
      case 'Orange':
        return Colors.orange;
      case 'Strawberry':
        return Colors.red;
      case 'Blueberry':
        return Colors.indigo;
      case 'Watermelon':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}