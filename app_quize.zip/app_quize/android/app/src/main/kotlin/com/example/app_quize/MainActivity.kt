package com.example.app_quize

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
